#!/bin/bash
# -----------------------
# Alex Lomsadze
# 2020
# GeneMark-ES installation check
# -----------------------

echo "Checking GeneMark-ES installation"

for value in YAML Hash::Merge Logger::Simple Parallel::ForkManager MCE::Mutex threads
do
  if ( ! perl -M$value -e 1 )
  then
    echo "Error, Perl CPAN library $value not found"
    exit 1
  fi
done

dir=$(dirname $0)
message=`$dir/gmhmme3 -v`

if [[ $message != "gmhmme3 : error, sequence file's name is not provided" ]]
then
  echo "Error, installation key is missing or expired"
  exit 1;
fi

echo "All required components for GeneMark-ES were found"

