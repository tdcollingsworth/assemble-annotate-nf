# GeneMark-E* Examples

Test examples for eukaryotic GeneMark-E* which serve to:

  * Demonstrate the usage of GeneMark-E*
  * To test whether the program is correctly configured

